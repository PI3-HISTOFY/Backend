#!/bin/bash
echo "DEEPSEEK_API_KEY=$DEEPSEEK_API_KEY" > /var/app/staging/.env